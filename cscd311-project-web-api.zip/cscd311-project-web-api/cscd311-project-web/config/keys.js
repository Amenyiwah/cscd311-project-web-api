module.exports= 
{
    MongoURI:
    'mongodb+srv://dexoangle_db:professor001@cluster0-xtzoi.mongodb.net/test?retryWrites=true&w=majority'
}